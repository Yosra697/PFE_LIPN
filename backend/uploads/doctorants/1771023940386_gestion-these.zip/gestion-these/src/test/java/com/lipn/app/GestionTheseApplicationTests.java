package com.lipn.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionTheseApplicationTests {

	@Test
	void contextLoads() {
	}

}
